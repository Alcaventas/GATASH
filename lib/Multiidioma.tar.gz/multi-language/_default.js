// Importar los archivos (MID-GB)
import es from './spanish-es.js' 
import en from './english-en.js' 

// Exportar los archivos (MID-GB) de forma global
export { es, en }

const MID_GB = {
idioma: 'English',
idioma_code: 'en',

//main.js
methodCode1: 'BINDING METHOD',
methodCode2: 'HOW DO YOU WANT TO CONNECT?',
methodCode3: 'Option',
methodCode4: 'QR code',
methodCode5: '8 digit code.',
methodCode6: 'Write only the number of',
methodCode7: 'the option to connect.',
methodCode8: 'ADVICE',
methodCode9: 'If you use Termux, Replit, Linux, or Windows',
methodCode10: 'Use these commands for direct execution:',
methodCode11: (chalk) => `NUMBERS OTHER THAN ARE NOT ALLOWED ${chalk.bold.greenBright("1")} O ${chalk.bold.greenBright("2")}, NO LETTERS OR SPECIAL SYMBOLS.\n${chalk.bold.yellowBright("TIP: COPY THE OPTION NUMBER AND PASTE IT INTO THE CONSOLE.")}`,
methodCode12: 'Start with QR code',
methodCode13: 'Start with 8 digit code',
methodCode14: 'Default startup with options'
}

export default MID_GB
